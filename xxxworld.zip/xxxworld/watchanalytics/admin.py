from django.contrib import admin
from. models import Analytics

admin.site.register(Analytics)
# Register your models here.
